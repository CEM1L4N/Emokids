//
//  Tag.swift
//  EmoKids
//
//  Created by Luthfi Asmara on 24/07/23.
//

import Foundation

struct Tag: Hashable {
    let tag: String
}

var tagsKey: [Tag] = [

]
