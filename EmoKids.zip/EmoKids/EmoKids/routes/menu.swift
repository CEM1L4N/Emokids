//
//  menu.swift
//  EmoKids
//
//  Created by Luthfi Asmara on 23/06/23.
//

import Foundation
import SwiftUI

enum Menu: String{
    case home
    case record
    case recordrunning
}
